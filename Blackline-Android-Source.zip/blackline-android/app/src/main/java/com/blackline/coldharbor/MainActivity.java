package com.blackline.coldharbor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.Surface;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebResourceErrorCompat;
import androidx.webkit.WebViewClientCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/** Android host for the bundled prototype. No remote page or network permission. */
public final class MainActivity extends Activity implements SensorEventListener {
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final String START_URL = ORIGIN + "/assets/game/index.html";
    private FrameLayout root;
    private WebView webView;
    private SensorManager sensors;
    private Sensor gyroscope;
    private Vibrator vibrator;
    private boolean foreground;
    private boolean gyroRequested;
    private boolean gyroRegistered;
    private boolean sessionActive;
    private long sensorTimestamp;
    private long lastDelivery;
    private float accumulatedYaw;
    private float accumulatedPitch;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyroscope = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(16, 22, 20));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.displayCutout());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
        } else if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams attributes = getWindow().getAttributes();
            attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER;
            getWindow().setAttributes(attributes);
        }
        createWebView();
        immersive();
    }

    @SuppressLint("SetJavaScriptEnabled")
    @SuppressWarnings("deprecation")
    private void createWebView() {
        if (webView != null) {
            root.removeView(webView);
            webView.destroy();
        }
        root.removeAllViews();
        sessionActive = false;
        gyroRequested = false;
        updateGyroscope();
        updateWakeState();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16, 22, 20));
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        WebSettings options = webView.getSettings();
        options.setJavaScriptEnabled(true);
        options.setDomStorageEnabled(true);
        options.setAllowFileAccess(false);
        options.setAllowContentAccess(false);
        options.setAllowFileAccessFromFileURLs(false);
        options.setAllowUniversalAccessFromFileURLs(false);
        options.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        options.setMediaPlaybackRequiresUserGesture(true);
        options.setSupportMultipleWindows(false);
        options.setJavaScriptCanOpenWindowsAutomatically(false);
        options.setBuiltInZoomControls(false);
        options.setSupportZoom(false);
        options.setTextZoom(100);

        WebViewAssetLoader assets = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (!trusted(request.getUrl())) return blockedResponse();
                WebResourceResponse response = assets.shouldInterceptRequest(request.getUrl());
                return response == null ? blockedResponse() : response;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !trusted(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !trusted(Uri.parse(url));
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceErrorCompat error) {
                if (request.isForMainFrame()) showError(getString(R.string.load_error));
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                root.removeView(view);
                view.destroy();
                webView = null;
                sessionActive = false;
                gyroRequested = false;
                updateGyroscope();
                updateWakeState();
                showError(getString(R.string.renderer_error));
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) { request.deny(); }
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                if (BuildConfig.DEBUG) android.util.Log.d("BLACKLINE", message.message());
                return true;
            }
        });
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(webView, "BlacklineNative", Collections.singleton(ORIGIN),
                (view, message, sourceOrigin, isMainFrame, reply) -> {
                    if (!isMainFrame || !"https".equals(sourceOrigin.getScheme())
                        || !"appassets.androidplatform.net".equals(sourceOrigin.getHost())
                        || (sourceOrigin.getPort() != -1 && sourceOrigin.getPort() != 443)) return;
                    handleMessage(message, reply);
                });
        }
        webView.loadUrl(START_URL);
    }

    private boolean trusted(Uri uri) {
        return "https".equals(uri.getScheme())
            && "appassets.androidplatform.net".equals(uri.getHost())
            && (uri.getPort() == -1 || uri.getPort() == 443)
            && uri.getPath() != null && uri.getPath().startsWith("/assets/game/");
    }

    private WebResourceResponse blockedResponse() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
            Collections.emptyMap(), new ByteArrayInputStream("Unavailable".getBytes(StandardCharsets.UTF_8)));
    }

    private void handleMessage(WebMessageCompat message, JavaScriptReplyProxy reply) {
        int id = -1;
        try {
            String text = message.getData();
            if (text == null || text.length() > 4096) return;
            JSONObject request = new JSONObject(text);
            id = request.optInt("id", -1);
            String type = request.optString("type", "");
            JSONObject data = request.optJSONObject("data");
            JSONObject result = new JSONObject();
            switch (type) {
                case "capabilities":
                    result.put("android", true);
                    result.put("gyroscope", gyroscope != null);
                    result.put("haptics", vibrator != null && vibrator.hasVibrator());
                    result.put("version", BuildConfig.VERSION_NAME);
                    break;
                case "haptic":
                    if (foreground && data != null) vibrate(data.optJSONArray("pattern"));
                    result.put("accepted", foreground);
                    break;
                case "gyro.enable":
                    gyroRequested = gyroscope != null;
                    updateGyroscope();
                    result.put("enabled", gyroRequested);
                    break;
                case "gyro.disable":
                    gyroRequested = false;
                    updateGyroscope();
                    result.put("enabled", false);
                    break;
                case "session":
                    sessionActive = data != null && data.optBoolean("active", false);
                    updateWakeState();
                    updateGyroscope();
                    result.put("active", sessionActive);
                    break;
                default:
                    throw new JSONException("Comandă necunoscută");
            }
            reply.postMessage(new JSONObject().put("id", id).put("ok", true).put("result", result).toString());
        } catch (Exception error) {
            try {
                reply.postMessage(new JSONObject().put("id", id).put("ok", false)
                    .put("error", "Comanda Android nu a putut fi executată.").toString());
            } catch (JSONException ignored) { }
        }
    }

    private void vibrate(JSONArray requested) {
        if (requested == null || requested.length() == 0 || vibrator == null || !vibrator.hasVibrator()) return;
        int count = Math.min(9, requested.length());
        long[] timings = new long[count + 1];
        int[] amplitudes = new int[count + 1];
        for (int i = 0; i < count; i++) {
            timings[i + 1] = Math.max(0, Math.min(200, requested.optLong(i, 0)));
            amplitudes[i + 1] = i % 2 == 0 ? VibrationEffect.DEFAULT_AMPLITUDE : 0;
        }
        long total = 0;
        for (long t : timings) total += t;
        if (total > 0) vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1));
    }

    private void updateWakeState() {
        if (foreground && sessionActive) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void updateGyroscope() {
        boolean desired = foreground && sessionActive && gyroRequested && gyroscope != null;
        if (desired && !gyroRegistered) {
            sensorTimestamp = 0;
            lastDelivery = 0;
            accumulatedYaw = accumulatedPitch = 0;
            gyroRegistered = sensors.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_GAME);
        } else if (!desired && gyroRegistered) {
            sensors.unregisterListener(this);
            gyroRegistered = false;
            sensorTimestamp = 0;
        }
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (!foreground || !gyroRegistered || webView == null || !sessionActive) {
            sensorTimestamp = 0;
            return;
        }
        if (sensorTimestamp == 0) { sensorTimestamp = event.timestamp; return; }
        float dt = Math.min(0.05f, Math.max(0, (event.timestamp - sensorTimestamp) / 1_000_000_000f));
        sensorTimestamp = event.timestamp;
        float x = event.values[0], y = event.values[1], yaw, pitch;
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        switch (rotation) {
            case Surface.ROTATION_90: yaw = -x; pitch = y; break;
            case Surface.ROTATION_180: yaw = -y; pitch = -x; break;
            case Surface.ROTATION_270: yaw = x; pitch = -y; break;
            default: yaw = y; pitch = x;
        }
        accumulatedYaw += yaw * dt;
        accumulatedPitch += pitch * dt;
        if (event.timestamp - lastDelivery < 33_000_000L) return;
        lastDelivery = event.timestamp;
        try {
            JSONObject payload = new JSONObject().put("yaw", accumulatedYaw).put("pitch", accumulatedPitch);
            webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('blackline:gyro',{detail:" + payload + "}));", null);
        } catch (JSONException ignored) { }
        accumulatedYaw = accumulatedPitch = 0;
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private void emit(String event) {
        if (webView != null) webView.evaluateJavascript("window.dispatchEvent(new Event('blackline:" + event + "'));", null);
    }

    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        if (webView != null) {
            webView.resumeTimers();
            webView.onResume();
            if (WebViewFeature.isFeatureSupported(WebViewFeature.MUTE_AUDIO)) WebViewCompat.setAudioMuted(webView, false);
            emit("foreground");
        }
        updateGyroscope();
        updateWakeState();
        immersive();
    }

    @Override protected void onPause() {
        foreground = false;
        sessionActive = false;
        updateGyroscope();
        updateWakeState();
        if (vibrator != null) vibrator.cancel();
        if (webView != null) {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.MUTE_AUDIO)) WebViewCompat.setAudioMuted(webView, true);
            emit("pause");
            webView.onPause();
        }
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (sensors != null) sensors.unregisterListener(this);
        if (vibrator != null) vibrator.cancel();
        if (webView != null) {
            root.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView == null) { finish(); return; }
        webView.evaluateJavascript("window.BlacklineAndroidBack ? window.BlacklineAndroidBack() : false", result -> {
            if (!"true".equals(result) && !isFinishing()) {
                new AlertDialog.Builder(this).setTitle("Închizi BLACKLINE?")
                    .setMessage("Preferințele rămân salvate pe dispozitiv.")
                    .setNegativeButton("Rămân", (dialog, which) -> immersive())
                    .setPositiveButton("Închide", (dialog, which) -> finish()).show();
            }
        });
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @SuppressWarnings("deprecation")
    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    private void showError(String text) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(48, 30, 48, 30);
        panel.setBackgroundColor(Color.rgb(16, 22, 20));
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.rgb(231, 233, 222));
        label.setTextSize(18);
        label.setGravity(Gravity.CENTER);
        Button retry = new Button(this);
        retry.setText(R.string.retry);
        retry.setOnClickListener(view -> createWebView());
        panel.addView(label);
        panel.addView(retry);
        root.addView(panel, new FrameLayout.LayoutParams(-1, -1));
    }
}
