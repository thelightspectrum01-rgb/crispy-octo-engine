export const WEAPONS = {
  m4: {name:'M4A1',class:'PUȘCĂ DE ASALT',caliber:'5.56 × 45',description:'Echilibru între mobilitate, control și cadență. Platforma versatilă a operatorului.',color:[.28,.3,.24],damage:30,rpm:740,capacity:30,reserve:150,speed:880,recoil:.021,spread:.014,reload:2.3,emptyReload:2.85,weight:3.1,range:75,auto:true,sound:160},
  ak: {name:'AK-74',class:'PUȘCĂ DE ASALT',caliber:'5.45 × 39',description:'Mecanică robustă. Recul perceptibil, foc susținut și penetrare eficientă.',color:[.24,.25,.22],damage:35,rpm:630,capacity:30,reserve:150,speed:900,recoil:.028,spread:.016,reload:2.7,emptyReload:3.2,weight:3.3,range:80,auto:true,sound:115},
  mk: {name:'MK 14',class:'PUȘCĂ DE PRECIZIE',caliber:'7.62 × 51',description:'Lovituri deliberate la distanță. Calibru puternic, ritm controlat, recul amplu.',color:[.34,.35,.27],damage:68,rpm:260,capacity:20,reserve:80,speed:850,recoil:.043,spread:.007,reload:2.85,emptyReload:3.4,weight:4.5,range:110,auto:false,sound:85}
};
export const DEFAULTS = {quality:'auto',fps:60,fov:78,sensitivity:1,assist:.15,buttonScale:1,showFps:false,invertY:false,volume:.65,haptics:true,weather:'rain',time:'dawn'};
export const DEFAULT_LOADOUT = {weapon:'m4',optic:'holo',muzzle:'standard',grip:'standard'};
const storage={get(k){try{return JSON.parse(localStorage.getItem(k))}catch{return null}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch{return false}}};
export const settings=Object.assign({},DEFAULTS,storage.get('blackline.settings'));
export const loadout=Object.assign({},DEFAULT_LOADOUT,storage.get('blackline.loadout'));
if(!WEAPONS[loadout.weapon])loadout.weapon='m4';
export const preferences={saveSettings:()=>storage.set('blackline.settings',settings),saveLoadout:()=>storage.set('blackline.loadout',loadout),getLayout:()=>storage.get('blackline.layout')||{},saveLayout:v=>storage.set('blackline.layout',v),getBest:()=>storage.get('blackline.best'),saveBest:v=>storage.set('blackline.best',v)};
export function weaponStats(config=loadout){const w={...WEAPONS[config.weapon]};if(config.muzzle==='suppressor'){w.weight+=.35;w.speed*=.98;w.recoil*=.94}if(config.muzzle==='compensator')w.recoil*=.75;if(config.grip==='vertical'){w.recoil*=.85;w.weight+=.12}return w}
export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
