// Native bridge is injected only for the packaged, trusted top-level origin.
const transport = globalThis.BlacklineNative;
let sequence = 0;
const requests = new Map();
export const isAndroid = Boolean(transport?.postMessage);
if (isAndroid) {
  transport.onmessage = event => {
    let message;
    try { message = JSON.parse(event.data); } catch { return; }
    const pending = requests.get(message.id);
    if (!pending) return;
    clearTimeout(pending.timer);
    requests.delete(message.id);
    if (message.ok) pending.resolve(message.result);
    else pending.reject(new Error(message.error || 'Integrarea Android nu este disponibilă.'));
  };
}

export function nativeRequest(type, data = {}) {
  if (!isAndroid) return Promise.reject(new Error('Integrarea Android nu este disponibilă.'));
  return new Promise((resolve, reject) => {
    const id = ++sequence;
    const timer = setTimeout(() => {
      requests.delete(id);
      reject(new Error('Android nu a răspuns la comandă.'));
    }, 2500);
    requests.set(id, {resolve, reject, timer});
    try { transport.postMessage(JSON.stringify({id, type, data})); }
    catch (error) { clearTimeout(timer); requests.delete(id); reject(error); }
  });
}

export function nativeHaptic(pattern) {
  if (!isAndroid) return false;
  nativeRequest('haptic', {pattern: Array.isArray(pattern) ? pattern : [pattern]}).catch(() => {});
  return true;
}

export function nativeSession(active) {
  if (isAndroid) nativeRequest('session', {active: Boolean(active)}).catch(() => {});
}
