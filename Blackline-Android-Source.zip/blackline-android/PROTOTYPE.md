# BLACKLINE — Cold Harbor

Prototip FPS 3D jucabil, în limba română, cu o misiune solo. Acesta este un vertical slice pentru evaluarea mecanicilor și a direcției de produs. Nu este un joc AAA terminat, un APK sau o aplicație iOS semnată. Imaginea cinematică din meniu este concept art generat; lumea jucabilă folosește geometrie și materiale procedurale.

## Pornire

Sursele și resursele publice se află în `dist/`. Nu există pachete de instalat sau servicii terțe necesare la rulare. Servește directorul prin HTTP/HTTPS, de exemplu cu `python3 -m http.server 8000 --directory dist`, apoi deschide adresa serverului într-un browser cu WebGL 2. Pentru acces de pe telefon, folosește o adresă HTTPS accesibilă dispozitivului. Giroscopul și fullscreen depind de permisiunile și capabilitățile browserului.

## Experiența implementată

- Operațiune solo: intrare în port, recuperarea datelor, revenire la extracție; debriefing cu timp, precizie și eliminări.
- Trei arme configurabile: M4A1, AK-74 și MK 14; profiluri diferite pentru cadență, calibru, damage, recul, viteză, greutate și reîncărcare.
- Recul procedural, sway, inerție vizuală, ADS, hip fire, animații procedurale de mers/sprint/reîncărcare/inspecție, ejectarea tuburilor, flash și particule.
- Proiectile simulate în timp cu gravitație; teste de coliziune pe întreaga traiectorie a cadrului; penetrarea lemnului și a sticlei; ricoșeu limitat la unghi mic pe metal. Damage pentru cap, corp și picioare.
- Încărcare tactică și din gol; în modul tactic se păstrează încărcătoarele parțiale separat. HUD redus și damage mai mare. Modul standard recuperează lent sănătatea după o perioadă fără damage.
- Deplasare, sprint, ghemuire, culcat, săritură peste obstacole mici, înclinare, lanternă, două grenade. Corp vizibil când privești în jos.
- Șase adversari cu vedere limitată de distanță, con de vedere și obstacole. Investighează zgomote, păstrează ultima poziție cunoscută, comunică între vecini, folosesc rute ocolitoare, flanchează și încearcă să se retragă la sănătate redusă.
- Hartă industrială cu depozit explorabil, containere, acoperire, obiecte destructibile, sticlă și ușă acționabilă.
- Sunet procedural Web Audio cu panning HRTF, atenuare cu distanța, reverberație de interior, ploaie, pași, explozii, mecanisme și feedback haptic unde este suportat. Sunetele sunt sintetizate, nu înregistrări de arme reale.
- Controale tactile cu joystick și privire simultană; poziții și dimensiuni individuale editabile; sensibilitate, invert Y, assist discret și giroscop opțional. Preferințele sunt locale dispozitivului.
- WebGL 2 fără dependențe: geometrie instanțiată, iluminare direcțională de tip PBR, umbre, ceață, suprafețe procedurale, ploaie și vegetație animată. Pool de efecte și rezoluție adaptivă. Limitatoare de 30/60/120 FPS; frecvențele nu sunt garantate sau certificate.
- Arsenal cu previzualizare 3D și accesorii care modifică modelul și comportamentul.

## Module

| Modul | Responsabilitate |
|---|---|
| `config.js` | Date arme, accesorii, preferințe |
| `renderer.js` | Matematică 3D, graph de scene, instancing, materiale, umbre |
| `world.js` | Geometrie, coliziuni, distrugeri, uși, navigație |
| `input.js` | Keyboard/mouse, touch, layout, giroscop |
| `weapons.js` | Model procedural, muniție, recoil, reload |
| `audio.js` | Sinteză, sunet spațial, reverberație, haptics |
| `ai.js` | Percepție, memorie, decizie, mișcare și reacții |
| `effects.js` | Pool particule, decal-uri, vreme |
| `game.js` | Simulare, proiectile, damage, obiective, stări de joc |
| `app.js` | Meniuri, fluxuri, dialoguri și configurare |

## Limitele prototipului și etapele pentru producție

Nu sunt implementate: multiplayer sau servere authoritative; matchmaking și anti-cheat; campanie cu mai multe misiuni; modurile 5v5–20v20, TDM, Domination, Search & Destroy, Extraction multiplayer sau Battle Royale; vehicule pilotabile; schelete animate cu IK, mocap și ragdoll fizic complet; GI dinamică, SSR, volumetrie reală, texture streaming 2K/4K; distrugere structurală; vault/climb/slide dedicate; voice acting și mixaj audio de producție. Ziua și vremea se aleg înaintea misiunii; nu există încă un ciclu temporal complet. AI-ul nu include grenade sau salvarea colegilor. Nu este inclus friendly fire deoarece nu există coechipieri.

Pentru Android/iOS nativ, următoarea etapă este o implementare într-un motor de producție, cu asset-uri artistice optimizate, pipeline de animație, instrumente de profiling, build-uri semnate și teste termice pe dispozitive reale. Logica și configurațiile acestui prototip sunt separate pentru referință și portare; rendererul browserului nu reprezintă un motor AAA nativ. O simplă împachetare WebView nu garantează nivelul vizual sau performanța cerută.

Pentru multiplayer, serverul va deține simularea autoritativă a mișcării, damage-ului, muniției și obiectivelor. Clientul va avea input prediction, reconciliation, interpolare și confirmarea loviturilor; acest contract trebuie construit și verificat înainte de a deschide modurile competitive. Nu există în acest prototip un serviciu de rețea sau o protecție anti-cheat simulată.

## Verificare

`node --test tests/simulation.test.mjs` verifică scenariile de coliziune balistică, încărcătoarele tactice, configurațiile armelor, starea de muniție și geometria hărții. Verificările automate nu certifică randarea pe GPU, atingerea țintelor FPS sau funcționarea pe hardware Android/iOS. Testele manuale pe dispozitive fizice rămân necesare înainte de distribuție.

## Resurse și licențe

Concept art: generat pentru BLACKLINE. Codul aplicației: scris pentru acest proiect. Fontul de afișare este o variantă condensată a DejaVu Sans Bold, distribuit sub licența DejaVu/Bitstream; vezi `FONT-LICENSE.txt`. Jocul nu include sunete sau modele comerciale din alte jocuri.
