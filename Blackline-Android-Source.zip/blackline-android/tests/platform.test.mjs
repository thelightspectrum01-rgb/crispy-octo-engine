import test from 'node:test';
import assert from 'node:assert/strict';
const entry='../app/src/main/assets/game/js/platform.js';

test('Native request resolves only its matching reply and preserves message data',async()=>{
  let sent;
  globalThis.BlacklineNative={postMessage(value){sent=JSON.parse(value)}};
  const p=await import(entry+'?connected');
  assert.equal(p.isAndroid,true);
  const request=p.nativeRequest('gyro.enable',{requested:true});
  assert.equal(sent.type,'gyro.enable');
  assert.equal(sent.data.requested,true);
  BlacklineNative.onmessage({data:'invalid JSON'});
  BlacklineNative.onmessage({data:JSON.stringify({id:9999,ok:true,result:{enabled:false}})});
  BlacklineNative.onmessage({data:JSON.stringify({id:sent.id,ok:true,result:{enabled:true}})});
  assert.deepEqual(await request,{enabled:true});
});

test('Native rejection is exposed to the caller',async()=>{
  let sent;
  globalThis.BlacklineNative={postMessage(value){sent=JSON.parse(value)}};
  const p=await import(entry+'?error');
  const request=p.nativeRequest('gyro.enable');
  BlacklineNative.onmessage({data:JSON.stringify({id:sent.id,ok:false,error:'Sensor unavailable'})});
  await assert.rejects(request,/Sensor unavailable/);
});

test('Without Android, haptics fall back and requests fail deliberately',async()=>{
  delete globalThis.BlacklineNative;
  const p=await import(entry+'?browser');
  assert.equal(p.isAndroid,false);
  assert.equal(p.nativeHaptic([10]),false);
  await assert.rejects(p.nativeRequest('capabilities'),/Android/);
});

test('Disconnected transport rejects immediately without leaving a timer',async()=>{
  globalThis.BlacklineNative={postMessage(){throw Error('Bridge disconnected')}};
  const p=await import(entry+'?disconnected');
  await assert.rejects(p.nativeRequest('session',{active:true}),/Bridge disconnected/);
});
