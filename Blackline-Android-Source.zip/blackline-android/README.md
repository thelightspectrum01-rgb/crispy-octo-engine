# BLACKLINE — proiect Android

Acest pachet conține proiectul sursă Android al prototipului Cold Harbor. **Nu conține un APK compilat.** Android SDK, Gradle și un JDK complet nu au fost disponibile în mediul de autorare, astfel că aplicația nu a putut fi compilată sau testată pe un telefon.

Este o aplicație Android cu host Java și motorul WebGL al prototipului inclus local într-un WebView. Nu deschide site-ul online și nu cere autentificare ChatGPT. Jocul, imaginile, fontul și sunetele procedurale sunt incluse în proiect; după compilare, această versiune este proiectată pentru funcționare offline. Această împachetare nu transformă grafica prototipului într-un motor AAA nativ.

## Ce este pregătit în cod

- Activity Android cu lansare din launcher, mod landscape și interfață fullscreen.
- Fișiere locale servite prin `WebViewAssetLoader`, fără permisiunea INTERNET.
- Comenzi tactile, inclusiv grenade, lanternă și poziție culcat.
- Vibrații prin API-ul Android, pornite din evenimentele de tragere, impact și reîncărcare.
- Giroscop nativ, cu transformarea axelor pentru orientarea ecranului și activare din Setări.
- Pauză la trecerea aplicației în fundal; oprirea senzorului, vibrațiilor și a sunetului. Reluarea misiunii este manuală.
- Butonul Android Back pentru închiderea ferestrelor, pauză sau revenire la meniu.
- Ecran ținut aprins numai în timpul misiunii active.
- Preferințe locale și ecran de recuperare dacă procesul de randare se oprește.
- Punte JavaScript–Android restrânsă la originea locală și documentul principal.

Aceste integrări necesită validare pe dispozitiv. Pe un WebView vechi fără suportul punții de mesaje, jocul poate folosi comenzile tactile și fallback-urile web; actualizarea Android System WebView este recomandată.

## Generarea APK-ului

Pe un calculator Windows, macOS sau Linux:

1. Instalează Android Studio și, în SDK Manager, **Android SDK Platform 35** și **Android SDK Build-Tools 35.0.0**. Este necesar un JDK complet 17 sau 21 și Python 3.10+.
2. Dezarhivează acest proiect. Setează `JAVA_HOME` la JDK și `ANDROID_HOME` la Android SDK; alternativ, locația SDK poate fi furnizată de Android Studio în `local.properties`.
3. Din folderul proiectului, rulează:

   ```sh
   python3 scripts/build_android.py --check
   python3 scripts/build_android.py
   ```

   Pe Windows, folosește `py` în loc de `python3` dacă așa este instalat Python.

Scriptul verifică instrumentele, descarcă distribuția oficială Gradle 8.11.1, verifică SHA-256, generează wrapper-ul Gradle și rulează `assembleDebug` plus `lintDebug`. Primul build necesită internet pentru instrumente și dependențe. Nu acceptă în locul tău licențele SDK; finalizează configurarea SDK în Android Studio.

Dacă build-ul reușește, APK-ul de test apare în:

```text
output/Blackline-debug.apk
```

Instalare pe un dispozitiv conectat și autorizat pentru depanare USB:

```sh
adb install -r output/Blackline-debug.apk
```

După generarea wrapper-ului, proiectul poate fi deschis direct în Android Studio, iar build-urile pot folosi `./gradlew :app:assembleDebug` sau `gradlew.bat :app:assembleDebug`. Dacă ai deja Gradle 8.11.1, poți rula direct `gradle wrapper --gradle-version 8.11.1` și apoi deschide proiectul în Android Studio.

## Configurație

| Componentă | Valoare |
|---|---|
| Android minim | Android 8.0 / API 26 |
| Compile / target SDK | 35 / 35 |
| Android Gradle Plugin | 8.9.2 |
| Gradle | 8.11.1 |
| AndroidX WebKit | 1.12.1 |
| Package de bază | `com.blackline.coldharbor` |
| Package debug | `com.blackline.coldharbor.debug` |
| Versiune | 0.1.0 |
| Grafică necesară | WebGL 2 / OpenGL ES 3 |

Versiunile sunt fixate pentru această bază de dezvoltare. Configurația nu reprezintă o verificare a cerințelor curente de publicare în Google Play. Pentru distribuție publică sunt necesare un build release, cheia de semnare a proprietarului, verificarea cerințelor magazinului și teste reale.

## Structură

- `app/src/main/java/.../MainActivity.java`: host Android, lifecycle, mesaje, senzori, vibrații.
- `app/src/main/assets/game/`: jocul complet, inclus local în aplicație.
- `app/src/main/assets/game/js/platform.js`: contractul mesajelor Android.
- `scripts/build_android.py`: verificarea mediului și generarea APK-ului.
- `scripts/verify_sources.py`: verificări statice și inventarul resurselor.
- `tests/platform.test.mjs`: teste pentru puntea JavaScript.
- `PROTOTYPE.md`: sistemele și limitele motorului jucabil original.

## Stadiul verificării

Sunt verificate local sintaxa modulelor JavaScript, resursele și referințele, XML-urile Android, precum și răspunsurile și erorile punții JavaScript. Aceste verificări nu echivalează cu o compilare Android.

**Neexecutate:** build Gradle/Java/DEX, Android Lint, instalare APK, teste în emulator sau pe telefon, măsurarea FPS și consumului termic. Scriptul de build rulează compilarea și Lint numai într-un mediu care are SDK/JDK.

## Surse tehnice

- [Încărcarea conținutului local în WebView](https://developer.android.com/develop/ui/views/layout/webapps/load-local-content)
- [Compatibilitatea AGP 8.9](https://developer.android.com/build/releases/agp-8-9-0-release-notes)
- [AndroidX WebKit](https://developer.android.com/jetpack/androidx/releases/webkit)
- [WebViewCompat și puntea de mesaje](https://developer.android.com/reference/androidx/webkit/WebViewCompat)

Licența fontului este în `FONT-LICENSE.txt`. Imaginea din meniu este concept art generat pentru acest proiect.
