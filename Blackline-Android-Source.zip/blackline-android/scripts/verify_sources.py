#!/usr/bin/env python3
"""Source checks only; this is not an Android compilation or device test."""
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
GAME = ROOT / 'app/src/main/assets/game'
errors = []
node = shutil.which('node')
for file in GAME.rglob('*.js'):
    if node:
        result = subprocess.run([node, '--check', str(file)], capture_output=True, text=True)
        if result.returncode:
            errors.append(str(file.relative_to(ROOT)) + ': ' + result.stderr)
    for path in re.findall(r'from\s+[\'"]([^\'"]+)[\'"]', file.read_text()):
        if path.startswith('.') and not (file.parent / path).resolve().is_file():
            errors.append('Missing module ' + path)
for file in ROOT.rglob('*.xml'):
    try:
        ET.parse(file)
    except ET.ParseError as error:
        errors.append(str(file) + ': ' + str(error))
html = (GAME / 'index.html').read_text()
ids = re.findall(r'\bid="([^"]+)"', html)
if len(ids) != len(set(ids)):
    errors.append('Duplicate DOM IDs')
for source in (html, (GAME / 'style.css').read_text()):
    for path in re.findall(r'(?:src="|href="|url\([\'"]?)(\./[^\'"\)]+)', source):
        if not (GAME / path).resolve().is_file():
            errors.append('Missing asset ' + path)
for file in ['app.js', 'game.js']:
    for identifier in re.findall(r"\$\('([a-zA-Z0-9-]+)'\)", (GAME / 'js' / file).read_text()):
        if identifier not in ids:
            errors.append('Unknown DOM ID ' + identifier)
manifest = ET.parse(ROOT / 'app/src/main/AndroidManifest.xml').getroot()
namespace = '{http://schemas.android.com/apk/res/android}'
permissions = [x.attrib.get(namespace + 'name') for x in manifest.findall('uses-permission')]
if permissions != ['android.permission.VIBRATE']:
    errors.append('Unexpected permissions: ' + str(permissions))
if errors:
    raise SystemExit('\n'.join(errors))
print('PASS: local assets, module graph, DOM references, XML, offline permission set.')
print('JavaScript syntax: ' + ('PASS' if node else 'NOT RUN — Node.js is unavailable.'))
print('Android compilation and device testing: NOT RUN by this check.')
