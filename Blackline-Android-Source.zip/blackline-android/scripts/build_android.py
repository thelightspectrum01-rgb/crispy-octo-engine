#!/usr/bin/env python3
"""Build the Android debug APK on a computer with JDK and Android SDK installed.

Only --check is run in the authoring environment. The default build downloads
Gradle from its official distribution URL after local prerequisites are met.
"""
from __future__ import annotations
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
GRADLE_VERSION = '8.11.1'
SDK_API = '35'
BUILD_TOOLS = '35.0.0'


def executable(name: str) -> str:
    return name + ('.exe' if os.name == 'nt' else '')


def preflight() -> tuple[dict[str, str], list[str]]:
    env = dict(os.environ)
    problems = []
    java_dir = Path(env['JAVA_HOME']) if env.get('JAVA_HOME') else None
    java = str(java_dir / 'bin' / executable('java')) if java_dir else shutil.which('java')
    javac = str(java_dir / 'bin' / executable('javac')) if java_dir else shutil.which('javac')
    if not java or not javac or not Path(javac).is_file():
        problems.append('Lipsește JDK complet. Instalează JDK 17 sau JDK 21 și setează JAVA_HOME.')
    else:
        try:
            check = subprocess.run([javac, '-version'], capture_output=True, text=True, check=True)
            version = (check.stdout + check.stderr).strip().split()[-1].split('.')[0]
            if int(version) not in (17, 21):
                problems.append('Acest proiect fixează JDK 17 sau 21 pentru build-ul reproductibil.')
            env['PATH'] = str(Path(javac).parent) + os.pathsep + env.get('PATH', '')
        except (OSError, ValueError, subprocess.CalledProcessError):
            problems.append('JDK nu poate porni. Verifică JAVA_HOME și instalarea JDK.')
    sdk_value = env.get('ANDROID_HOME') or env.get('ANDROID_SDK_ROOT')
    if not sdk_value:
        properties = ROOT / 'local.properties'
        if properties.exists():
            for line in properties.read_text(encoding='utf-8').splitlines():
                if line.startswith('sdk.dir='):
                    sdk_value = line.partition('=')[2].replace('\\:', ':').replace('\\\\', '\\')
                    break
    if not sdk_value:
        problems.append('Lipsește Android SDK. Instalează-l din Android Studio și setează ANDROID_HOME.')
    else:
        sdk = Path(sdk_value).expanduser().resolve()
        env['ANDROID_HOME'] = str(sdk)
        env['ANDROID_SDK_ROOT'] = str(sdk)
        if not (sdk / 'platforms' / ('android-' + SDK_API) / 'android.jar').is_file():
            problems.append('Instalează Android SDK Platform 35 din SDK Manager.')
        if not (sdk / 'build-tools' / BUILD_TOOLS / executable('aapt2')).is_file():
            problems.append('Instalează Android SDK Build-Tools 35.0.0 din SDK Manager.')
    return env, problems


def fetch(url: str, destination: Path) -> None:
    request = urllib.request.Request(url, headers={'User-Agent': 'BlacklineAndroidBuild/0.1'})
    with urllib.request.urlopen(request, timeout=90) as response, destination.open('wb') as out:
        shutil.copyfileobj(response, out)


def gradle_distribution() -> tuple[Path, str]:
    tools = ROOT / '.tools'
    tools.mkdir(exist_ok=True)
    installation = tools / ('gradle-' + GRADLE_VERSION)
    launcher = installation / 'bin' / ('gradle.bat' if os.name == 'nt' else 'gradle')
    checksum_file = tools / ('gradle-' + GRADLE_VERSION + '.sha256')
    archive = tools / ('gradle-' + GRADLE_VERSION + '-bin.zip')
    url = 'https://services.gradle.org/distributions/gradle-' + GRADLE_VERSION + '-bin.zip'
    if not checksum_file.exists():
        fetch(url + '.sha256', checksum_file)
    expected = checksum_file.read_text().strip().split()[0].lower()
    if len(expected) != 64 or any(c not in '0123456789abcdef' for c in expected):
        raise RuntimeError('Checksum Gradle invalid.')
    if not archive.exists():
        print('Descarc Gradle ' + GRADLE_VERSION + ' din distribuția oficială...', flush=True)
        fetch(url, archive)
    actual = hashlib.sha256(archive.read_bytes()).hexdigest()
    if actual != expected:
        archive.unlink()
        raise RuntimeError('Arhiva Gradle nu corespunde checksum-ului oficial. Download-ul a fost eliminat.')
    if not launcher.exists():
        with zipfile.ZipFile(archive) as package:
            for item in package.infolist():
                target = (tools / item.filename).resolve()
                if not target.is_relative_to(tools.resolve()):
                    raise RuntimeError('Cale invalidă în arhiva Gradle.')
            package.extractall(tools)
        if os.name != 'nt':
            launcher.chmod(0o755)
    return launcher, expected


def main() -> int:
    args = argparse.ArgumentParser(description='BLACKLINE Android APK builder')
    args.add_argument('--check', action='store_true', help='Verifică JDK și SDK fără download sau compilare.')
    options = args.parse_args()
    env, problems = preflight()
    if problems:
        for problem in problems:
            print('NECESAR: ' + problem)
        print('Nu a fost generat niciun APK.')
        return 2
    print('JDK și Android SDK sunt disponibile.')
    if options.check:
        return 0
    gradle, checksum = gradle_distribution()
    # Generate the genuine Gradle wrapper as part of bootstrapping.
    common = [str(gradle), '--no-daemon', '--console=plain']
    subprocess.run(common + ['wrapper', '--gradle-version', GRADLE_VERSION,
        '--distribution-type', 'bin', '--gradle-distribution-sha256-sum', checksum],
        cwd=ROOT, env=env, check=True)
    subprocess.run(common + [':app:assembleDebug', ':app:lintDebug'], cwd=ROOT, env=env, check=True)
    apk = ROOT / 'app' / 'build' / 'outputs' / 'apk' / 'debug' / 'app-debug.apk'
    if not apk.is_file():
        raise RuntimeError('Build-ul nu a produs APK-ul așteptat.')
    output = ROOT / 'output'
    output.mkdir(exist_ok=True)
    target = output / 'Blackline-debug.apk'
    shutil.copy2(apk, target)
    print('APK debug generat: ' + str(target))
    print('Semnătură debug pentru testare; aceasta nu este o publicare în Google Play.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, subprocess.CalledProcessError, zipfile.BadZipFile) as error:
        print('Build oprit: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
